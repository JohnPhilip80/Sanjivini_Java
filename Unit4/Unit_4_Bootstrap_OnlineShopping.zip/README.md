# ShopEase — Bootstrap Online Shopping Platform

A responsive, front-end-only e-commerce classroom project for second-year undergraduate Computer Science students. It uses HTML5, CSS, Bootstrap 5.3.3, Bootstrap Icons, and vanilla JavaScript.

## Features
- Responsive navbar with collapsible mobile menu
- Hero banner, benefits, category cards, product cards, and footer
- Bootstrap grid system and responsive layout utilities
- Product search, category filtering, and sorting
- Add-to-cart interaction with quantity controls and remove action
- Cart displayed in a Bootstrap offcanvas panel
- Demo checkout in a Bootstrap modal with client-side validation
- Newsletter email validation and demo success message
- INR currency formatting
- Bootstrap Icons for decorative and interface icons

## Project structure
```text
bootstrap_online_shopping_project/
├── index.html
├── README.md
├── css/
│   └── style.css
└── js/
    └── app.js
```

## How to run
1. Extract the ZIP file.
2. Open `index.html` in a modern browser.
3. Keep an internet connection enabled so the Bootstrap CDN, Bootstrap Icons, and remote product photos can load.

Optional recommended method for class: open the folder in Visual Studio Code and run `index.html` using the Live Server extension.

## Important scope note
This is a front-end learning project. Cart contents exist only in browser memory and reset on refresh. Checkout generates a demo order number but does not contact a backend, save orders, send emails, authenticate users, or process payments. A production e-commerce platform would need a backend API, database, secure authentication, inventory/order management, server-side validation, and a compliant payment provider.

## 9-hour guided training plan
| Hour | Topic | Hands-on milestone |
|---|---|---|
| 1 | Introduction to Bootstrap | Create HTML shell, connect Bootstrap CDN, build navbar and buttons |
| 2 | Bootstrap Grid System | Build hero section and responsive category/product column layouts |
| 3 | Layout Utilities | Apply spacing, flex, alignment, display, background, border, and responsive utilities |
| 4 | Content & Typography | Style headings, paragraphs, badges, text colors, links, lists, and product descriptions |
| 5 | Components | Build navbar, cards, badges, buttons, offcanvas cart, and modal checkout |
| 6 | Forms in Bootstrap | Create search, newsletter, and checkout forms; add labels and validation feedback |
| 7 | Helpers and Utilities | Use visually-hidden labels, responsive helpers, object-fit custom CSS, and utility classes |
| 8 | Bootstrap Icons (optional) | Add cart, search, shipping, rating, and benefit icons; discuss accessible labels |
| 9 | Bootstrap JavaScript plugins | Use collapse, offcanvas, modal, and form validation; test full user journey and recap |

## Instructor suggestions
- Start with the static layout before introducing JavaScript.
- Have students inspect each Bootstrap class in browser DevTools.
- Ask learners to change a product, price, category, and image in `js/app.js`.
- Stretch task: add a wishlist button or persist the cart with `localStorage`.
- Stretch task: create a separate product details page.
- Assessment idea: ask students to demonstrate mobile responsiveness, filtering, cart quantity changes, and checkout validation.

## CDN versions
Bootstrap CSS and JS bundle: 5.3.3  
Bootstrap Icons: 1.11.3
