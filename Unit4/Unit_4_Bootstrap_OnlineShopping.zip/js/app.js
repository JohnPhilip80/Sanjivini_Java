// ShopEase app logic: product data, search, filtering, cart, and demo checkout.
const products = [
  { id: 1, name: "Everyday Cotton T-Shirt", category: "Fashion", price: 599, oldPrice: 799, rating: 4.7, badge: "Bestseller", image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80", description: "Soft cotton comfort for everyday wear." },
  { id: 2, name: "Wireless Headphones", category: "Electronics", price: 2499, oldPrice: 3199, rating: 4.8, badge: "Popular", image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80", description: "Enjoy music and calls with rich sound." },
  { id: 3, name: "Minimal Desk Lamp", category: "Home", price: 1299, oldPrice: 1599, rating: 4.5, badge: "New", image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80", description: "A clean, modern lamp for your workspace." },
  { id: 4, name: "Classic Wristwatch", category: "Accessories", price: 1899, oldPrice: 2299, rating: 4.6, badge: "Trending", image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80", description: "A timeless everyday accessory." },
  { id: 5, name: "Canvas Travel Backpack", category: "Fashion", price: 1599, oldPrice: 1999, rating: 4.4, badge: "Deal", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80", description: "Roomy, practical storage for daily travel." },
  { id: 6, name: "Ceramic Coffee Mug Set", category: "Home", price: 799, oldPrice: 999, rating: 4.3, badge: "", image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=800&q=80", description: "A simple set for your morning coffee." },
  { id: 7, name: "Smart Fitness Band", category: "Electronics", price: 2199, oldPrice: 2799, rating: 4.5, badge: "Popular", image: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?auto=format&fit=crop&w=800&q=80", description: "Track activity and keep your goals in view." },
  { id: 8, name: "Everyday Sunglasses", category: "Accessories", price: 999, oldPrice: 1299, rating: 4.2, badge: "", image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80", description: "A versatile pair for sunny days." }
];

const cart = new Map();
let searchTerm = "";
let selectedCategory = "All";
const productGrid = document.getElementById("productGrid");
const cartCount = document.getElementById("cartCount");
const cartItems = document.getElementById("cartItems");
const cartSubtotal = document.getElementById("cartSubtotal");
const noResults = document.getElementById("noResults");
const money = (amount) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(amount);

function getVisibleProducts() {
  let result = products.filter((p) => {
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    const text = `${p.name} ${p.category} ${p.description}`.toLowerCase();
    return matchesCategory && text.includes(searchTerm.toLowerCase());
  });
  const sort = document.getElementById("sortFilter").value;
  if (sort === "price-low") result.sort((a, b) => a.price - b.price);
  if (sort === "price-high") result.sort((a, b) => b.price - a.price);
  if (sort === "name") result.sort((a, b) => a.name.localeCompare(b.name));
  return result;
}

function renderProducts() {
  const visible = getVisibleProducts();
  productGrid.innerHTML = visible.map((p) => `
    <div class="col-6 col-md-4 col-xl-3">
      <article class="card product-card h-100 bg-white">
        <div class="product-image-wrap">
          <img class="product-image" src="${p.image}" alt="${p.name}" loading="lazy">
          ${p.badge ? `<span class="badge text-bg-warning product-badge">${p.badge}</span>` : ""}
        </div>
        <div class="card-body d-flex flex-column">
          <div class="small text-secondary mb-1">${p.category}</div>
          <h3 class="h6 fw-bold">${p.name}</h3>
          <p class="small text-secondary flex-grow-1">${p.description}</p>
          <div class="product-rating mb-2" aria-label="${p.rating} out of 5 stars"><i class="bi bi-star-fill"></i> ${p.rating} <span class="text-secondary">(${Math.floor(p.rating * 23)} reviews)</span></div>
          <div class="mb-3"><span class="product-price">${money(p.price)}</span><span class="old-price">${money(p.oldPrice)}</span></div>
          <button class="btn btn-primary w-100" data-add-to-cart="${p.id}"><i class="bi bi-cart-plus me-1"></i>Add to cart</button>
        </div>
      </article>
    </div>`).join("");
  noResults.classList.toggle("d-none", visible.length !== 0);
}

function cartQuantity() {
  return [...cart.values()].reduce((sum, item) => sum + item.quantity, 0);
}
function cartTotal() {
  return [...cart.values()].reduce((sum, item) => sum + item.product.price * item.quantity, 0);
}
function addToCart(id) {
  const product = products.find((p) => p.id === Number(id));
  if (!product) return;
  const current = cart.get(product.id);
  cart.set(product.id, { product, quantity: current ? current.quantity + 1 : 1 });
  renderCart();
}
function changeQuantity(id, amount) {
  const current = cart.get(Number(id));
  if (!current) return;
  current.quantity += amount;
  if (current.quantity <= 0) cart.delete(Number(id));
  renderCart();
}
function removeFromCart(id) {
  cart.delete(Number(id));
  renderCart();
}
function renderCart() {
  cartCount.textContent = cartQuantity();
  cartSubtotal.textContent = money(cartTotal());
  document.getElementById("checkoutTotal").textContent = money(cartTotal());
  if (cart.size === 0) {
    cartItems.innerHTML = `<div class="text-center text-secondary py-5"><i class="bi bi-cart-x display-5"></i><p class="mt-3">Your cart is empty.</p><p class="small">Add a product to get started.</p></div>`;
    document.getElementById("checkoutButton").disabled = true;
    return;
  }
  document.getElementById("checkoutButton").disabled = false;
  cartItems.innerHTML = [...cart.values()].map(({ product: p, quantity }) => `
    <div class="cart-line">
      <img src="${p.image}" alt="${p.name}">
      <div>
        <div class="fw-semibold small">${p.name}</div>
        <div class="small text-secondary mb-2">${money(p.price)} each</div>
        <div class="d-flex justify-content-between align-items-center gap-2">
          <div class="quantity-control">
            <button type="button" aria-label="Decrease ${p.name} quantity" data-cart-minus="${p.id}">−</button>
            <span class="small">${quantity}</span>
            <button type="button" aria-label="Increase ${p.name} quantity" data-cart-plus="${p.id}">+</button>
          </div>
          <button class="btn btn-sm btn-link text-danger p-0" type="button" data-cart-remove="${p.id}">Remove</button>
        </div>
      </div>
    </div>`).join("");
}

document.getElementById("searchForm").addEventListener("submit", (event) => {
  event.preventDefault();
  searchTerm = document.getElementById("searchInput").value.trim();
  renderProducts();
  document.getElementById("products").scrollIntoView({ behavior: "smooth" });
});
document.getElementById("searchInput").addEventListener("input", (event) => {
  searchTerm = event.target.value.trim();
  renderProducts();
});
document.getElementById("categoryFilter").addEventListener("change", (event) => {
  selectedCategory = event.target.value;
  renderProducts();
});
document.getElementById("sortFilter").addEventListener("change", renderProducts);
document.querySelectorAll("[data-category]").forEach((button) => {
  button.addEventListener("click", () => {
    selectedCategory = button.dataset.category;
    document.getElementById("categoryFilter").value = selectedCategory;
    renderProducts();
    document.getElementById("products").scrollIntoView({ behavior: "smooth" });
  });
});
productGrid.addEventListener("click", (event) => {
  const button = event.target.closest("[data-add-to-cart]");
  if (button) {
    addToCart(button.dataset.addToCart);
    button.innerHTML = '<i class="bi bi-check2 me-1"></i>Added';
    setTimeout(() => { button.innerHTML = '<i class="bi bi-cart-plus me-1"></i>Add to cart'; }, 900);
  }
});
cartItems.addEventListener("click", (event) => {
  const plus = event.target.closest("[data-cart-plus]");
  const minus = event.target.closest("[data-cart-minus]");
  const remove = event.target.closest("[data-cart-remove]");
  if (plus) changeQuantity(plus.dataset.cartPlus, 1);
  if (minus) changeQuantity(minus.dataset.cartMinus, -1);
  if (remove) removeFromCart(remove.dataset.cartRemove);
});

document.getElementById("checkoutButton").addEventListener("click", () => {
  if (cart.size === 0) return;
  const cartCanvas = bootstrap.Offcanvas.getInstance(document.getElementById("cartPanel"));
  if (cartCanvas) cartCanvas.hide();
  document.getElementById("orderSuccess").classList.add("d-none");
  bootstrap.Modal.getOrCreateInstance(document.getElementById("checkoutModal")).show();
});

function activateValidation(form) {
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    event.stopPropagation();
    if (!form.checkValidity()) {
      form.classList.add("was-validated");
      return;
    }
    return true;
  });
}
const newsletterForm = document.getElementById("newsletterForm");
newsletterForm.addEventListener("submit", (event) => {
  event.preventDefault();
  event.stopPropagation();
  if (!newsletterForm.checkValidity()) {
    newsletterForm.classList.add("was-validated");
    return;
  }
  document.getElementById("newsletterMessage").textContent = "Thanks for subscribing! (Demo only—no email was sent.)";
  document.getElementById("newsletterMessage").classList.remove("text-secondary");
  document.getElementById("newsletterMessage").classList.add("text-success");
  newsletterForm.reset();
  newsletterForm.classList.remove("was-validated");
});
const checkoutForm = document.getElementById("checkoutForm");
checkoutForm.addEventListener("submit", (event) => {
  event.preventDefault();
  event.stopPropagation();
  if (!checkoutForm.checkValidity()) {
    checkoutForm.classList.add("was-validated");
    return;
  }
  const orderNumber = `SE-${Math.floor(100000 + Math.random() * 900000)}`;
  const success = document.getElementById("orderSuccess");
  success.textContent = `Demo order ${orderNumber} created successfully for ${money(cartTotal())}. No payment was taken and no order was sent to a server.`;
  success.classList.remove("d-none");
  cart.clear();
  renderCart();
  checkoutForm.reset();
  checkoutForm.classList.remove("was-validated");
});
document.getElementById("currentYear").textContent = new Date().getFullYear();

renderProducts();
renderCart();
