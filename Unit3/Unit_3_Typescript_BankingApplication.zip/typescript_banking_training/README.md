# CampusBank — TypeScript Banking Transaction Management

An educational browser application for second-year UG Computer Science students. It demonstrates TypeScript types, functions, classes, interfaces, union types, type narrowing, modules, npm, TypeScript strict checking, and Vite.

> **Important:** This is a classroom simulation, not a real banking system. Data is stored in browser localStorage. Do not use real customer information, real bank credentials, or real money.

## Prerequisites

- Node.js 20 or later recommended
- npm (installed with Node.js)
- VS Code or another code editor
- A modern browser

## Run the project

1. Extract the ZIP.
2. Open a terminal in the extracted `typescript_banking_training` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the development server:

   ```bash
   npm run dev
   ```

5. Open the local URL printed by Vite, usually `http://localhost:5173`.
6. Check TypeScript errors:

   ```bash
   npm run typecheck
   ```

7. Create a production build:

   ```bash
   npm run build
   ```

8. Preview the build:

   ```bash
   npm run preview
   ```

## Demo data

Two sample customers and accounts are created on first run:
- Ananya Kumar — account `10000001`
- Arjun Raj — account `10000002`

The balances and all transactions are simulated. Browser data persists in localStorage. Use the browser developer tools to clear the `campusbank-state-v1` localStorage key to reset it, or use the app's data reset exercise after adding a reset button.

## Folder structure

```text
typescript_banking_training/
├── index.html
├── package.json
├── tsconfig.json
└── src/
    ├── main.ts       # UI rendering and browser event handlers
    ├── bank.ts       # Banking business rules and OOP
    ├── storage.ts    # Repository interface and localStorage adapter
    ├── types.ts      # Interfaces, unions and request/result types
    └── style.css     # Responsive application styles
```

## Suggested 9-hour classroom schedule

| Time | Topic | Hands-on deliverable |
|---|---|---|
| 0:00–0:45 | Introduction to TypeScript | Setup, TypeScript vs JavaScript, compile/build |
| 0:45–1:45 | Type System | `Customer`, `BankAccount`, primitive types, arrays, strict checks |
| 1:45–2:45 | Functions | Validation, amount checking, deposit/withdraw functions |
| 2:45–4:00 | OOP in TypeScript | `Bank` class, constructor, private state, methods |
| 4:00–5:00 | Interfaces and Types | Customer/account/transaction contracts and repository interface |
| 5:00–6:15 | Advanced Types | Union types, discriminated unions, `OperationResult<T>`, narrowing |
| 6:15–7:15 | TypeScript with Build Tools | npm, tsconfig, Vite, typecheck and build |
| 7:15–8:30 | Guided integration lab | Customer creation, account opening, deposit, withdrawal, transfer |
| 8:30–9:00 | Testing and assessment | Run test cases, explain code, short challenge |

## Topic-by-topic teaching notes

### 1. Introduction to TypeScript
- Explain TypeScript as JavaScript with a static type system.
- Show `npm run dev` and the browser console.
- Explain that Vite serves TypeScript during development and bundles the app for production.
- Ask students to change the dashboard title and observe the browser update.

### 2. Type System
- `string`: customer name, email and account number.
- `number`: balances and transaction amounts.
- `boolean`: flags such as whether a transfer field is required.
- Arrays: `Customer[]`, `BankAccount[]`, `Transaction[]`.
- Optional property: `relatedAccount?: string`.
- Ask students to intentionally assign a string to `balance` and run `npm run typecheck`.

### 3. Functions
- `money`, `dateTime`, `customerName`, `validateAmount`, `createCustomer`.
- Explain parameters, return types, optional parameters and pure helper functions.
- Challenge: add a minimum opening-balance rule.

### 4. Object-Oriented Programming
- `Bank` encapsulates state and business rules.
- `private state` prevents direct access from outside the class.
- Constructor injection provides the repository.
- Ask students to add a method that freezes an account and blocks transactions.

### 5. Interfaces and Types
- Interfaces: `Customer`, `BankAccount`, `Transaction`, `StateRepository`.
- Type aliases: `AccountStatus`, `TransactionType`, `OperationResult<T>`.
- Ask students to add an optional `address` to `Customer`.

### 6. Advanced Types
- Literal unions: `"active" | "frozen" | "closed"`.
- Discriminated union: `TransactionRequest`, narrowed by `request.kind`.
- Generic result: `OperationResult<T>`.
- Type narrowing: check `result.success` before reading `data` or `error`.
- Ask students to add a new transaction request kind and handle it safely.

### 7. Build tools
- `package.json`: scripts and dependencies.
- `tsconfig.json`: strict compiler settings.
- `npm run typecheck`: detect type errors.
- `npm run build`: type-check and bundle into `dist/`.
- Ask students to inspect the production output and explain why source modules are bundled.

## Test checklist

1. Register a valid customer.
2. Try to register the same email again.
3. Open an account with a valid opening balance.
4. Deposit ₹500 and verify the balance increases.
5. Withdraw ₹200 and verify the balance decreases.
6. Attempt to withdraw more than the balance; it must fail.
7. Transfer ₹300 to a different account; both balances must update.
8. Attempt a transfer to the same account; it must fail.
9. Attempt an amount of zero or a negative amount; it must fail.
10. Refresh the browser and confirm that demo state persists.
11. Run `npm run typecheck` and `npm run build`.

## Suggested assessment (20 marks)

- Type definitions and interfaces — 4
- Correct deposit/withdrawal logic — 4
- Transfer validation and balance updates — 4
- OOP and encapsulation explanation — 3
- Build/typecheck success — 2
- UI usability and test evidence — 3

## Important limitations and next steps

- localStorage is editable by the user and is not a secure database.
- There is no login, server, audit-grade ledger, concurrency control, or real authorization.
- JavaScript floating-point numbers are used for a simple classroom example; real financial software should use integer minor units or a decimal-money library and server-side transactional processing.
- For a later full-stack project, replace localStorage with a backend API and a database, add authentication/authorization, server-side validation, secure audit logging, and automated tests.
