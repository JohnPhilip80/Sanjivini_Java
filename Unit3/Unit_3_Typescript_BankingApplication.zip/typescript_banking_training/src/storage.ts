import type { BankState } from "./types";

const STORAGE_KEY = "campusbank-state-v1";

export interface StateRepository {
  load(): BankState | null;
  save(state: BankState): void;
}

export class LocalStorageRepository implements StateRepository {
  load(): BankState | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as BankState) : null;
    } catch {
      return null;
    }
  }

  save(state: BankState): void {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }
}
