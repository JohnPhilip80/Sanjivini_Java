// Interfaces and types: the contracts used throughout the application.
export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  createdAt: string;
}

export type AccountStatus = "active" | "frozen" | "closed";
export type TransactionType = "deposit" | "withdrawal" | "transfer-in" | "transfer-out";
export type TransactionStatus = "success" | "failed";

export interface BankAccount {
  accountNumber: string;
  customerId: string;
  balance: number;
  status: AccountStatus;
  createdAt: string;
}

export interface Transaction {
  id: string;
  accountNumber: string;
  type: TransactionType;
  amount: number;
  balanceAfter: number;
  description: string;
  timestamp: string;
  status: TransactionStatus;
  relatedAccount?: string;
}

export interface BankState {
  customers: Customer[];
  accounts: BankAccount[];
  transactions: Transaction[];
}

export type OperationResult<T> =
  | { success: true; data: T; message: string }
  | { success: false; error: string };

export type TransactionRequest =
  | { kind: "deposit"; accountNumber: string; amount: number }
  | { kind: "withdrawal"; accountNumber: string; amount: number }
  | { kind: "transfer"; fromAccount: string; toAccount: string; amount: number };
