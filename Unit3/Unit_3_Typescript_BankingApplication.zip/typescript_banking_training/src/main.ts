import "./style.css";
import { Bank } from "./bank";
import { LocalStorageRepository } from "./storage";
import type { BankAccount, Transaction, TransactionType } from "./types";

const bank = new Bank(new LocalStorageRepository());
const app = document.querySelector<HTMLDivElement>("#app");

if (!app) throw new Error("App root element was not found.");

let activeTab = "dashboard";
let notice: { text: string; kind: "success" | "error" } | null = null;
let searchTerm = "";

const money = (amount: number): string =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(amount);
const dateTime = (iso: string): string => new Date(iso).toLocaleString("en-IN");
const escapeHtml = (value: string): string => {
  const entities: Record<string, string> = {
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  };
  return value.replace(/[&<>"']/g, char => entities[char] ?? char);
};

function customerName(account: BankAccount): string {
  return bank.getCustomer(account.customerId)?.name ?? "Unknown customer";
}

function statusBadge(type: TransactionType): string {
  const labels: Record<TransactionType, string> = {
    deposit: "Deposit", withdrawal: "Withdrawal",
    "transfer-in": "Transfer in", "transfer-out": "Transfer out"
  };
  return `<span class="badge ${type}">${labels[type]}</span>`;
}

function transactionRows(items: Transaction[]): string {
  if (!items.length) return `<tr><td colspan="6" class="empty">No transactions yet.</td></tr>`;
  return items.map(tx => `
    <tr>
      <td>${escapeHtml(dateTime(tx.timestamp))}</td>
      <td>${escapeHtml(tx.accountNumber)}</td>
      <td>${statusBadge(tx.type)}</td>
      <td>${money(tx.amount)}</td>
      <td>${money(tx.balanceAfter)}</td>
      <td>${escapeHtml(tx.description)}</td>
    </tr>`).join("");
}

function accountOptions(selected = ""): string {
  return bank.getAccounts().map(account => `
    <option value="${account.accountNumber}" ${account.accountNumber === selected ? "selected" : ""}>
      ${account.accountNumber} — ${escapeHtml(customerName(account))} (${money(account.balance)})
    </option>`).join("");
}

function customerOptions(): string {
  return bank.getCustomers().map(customer =>
    `<option value="${customer.id}">${escapeHtml(customer.name)} (${escapeHtml(customer.id)})</option>`
  ).join("");
}

function dashboard(): string {
  const accounts = bank.getAccounts();
  const customers = bank.getCustomers();
  const txs = bank.getTransactions();
  const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0);
  return `
    <section class="stats">
      <article class="stat-card"><span>Total customers</span><strong>${customers.length}</strong><small>Registered customers</small></article>
      <article class="stat-card"><span>Bank accounts</span><strong>${accounts.length}</strong><small>Active demo accounts</small></article>
      <article class="stat-card"><span>Total deposits held</span><strong>${money(totalBalance)}</strong><small>Combined demo balance</small></article>
      <article class="stat-card"><span>Transactions</span><strong>${txs.length}</strong><small>Successful transactions</small></article>
    </section>
    <section class="panel">
      <div class="panel-heading"><div><h2>Accounts overview</h2><p>Search by account number or customer name.</p></div>
        <input id="account-search" type="search" placeholder="Search accounts..." value="${escapeHtml(searchTerm)}" /></div>
      ${accountsTable(accounts)}
    </section>
    <section class="panel"><div class="panel-heading"><div><h2>Recent transactions</h2><p>Latest activity across all accounts.</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>Date & time</th><th>Account</th><th>Type</th><th>Amount</th><th>Balance after</th><th>Description</th></tr></thead>
      <tbody>${transactionRows(txs.slice(0, 5))}</tbody></table></div>
    </section>`;
}

function accountsTable(accounts: BankAccount[]): string {
  const filtered = accounts.filter(account =>
    account.accountNumber.includes(searchTerm) ||
    customerName(account).toLowerCase().includes(searchTerm.toLowerCase()));
  if (!filtered.length) return `<p class="empty padded">No matching accounts found.</p>`;
  return `<div class="table-wrap"><table><thead><tr><th>Account number</th><th>Customer</th><th>Balance</th><th>Status</th><th>Opened</th></tr></thead><tbody>
    ${filtered.map(account => `<tr><td><strong>${escapeHtml(account.accountNumber)}</strong></td>
      <td>${escapeHtml(customerName(account))}</td><td>${money(account.balance)}</td>
      <td><span class="badge success">${account.status}</span></td><td>${escapeHtml(dateTime(account.createdAt))}</td></tr>`).join("")}
    </tbody></table></div>`;
}

function customersPage(): string {
  return `<div class="two-column">
    <section class="panel"><div class="panel-heading"><div><h2>Register customer</h2><p>All fields are required.</p></div></div>
      <form id="customer-form" class="form">
        <label>Full name<input name="name" required minlength="2" placeholder="e.g. Priya Kumar" /></label>
        <label>Email address<input name="email" type="email" required placeholder="priya@example.com" /></label>
        <label>Phone number<input name="phone" required minlength="8" maxlength="15" placeholder="9876543210" /></label>
        <button class="primary" type="submit">Register customer</button>
      </form>
    </section>
    <section class="panel"><div class="panel-heading"><div><h2>Customer directory</h2><p>${bank.getCustomers().length} customer(s)</p></div></div>
      <div class="customer-list">${bank.getCustomers().map(c => `<article class="customer-item"><div class="avatar">${escapeHtml(c.name.slice(0, 1).toUpperCase())}</div><div><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(c.id)} · ${escapeHtml(c.email)}</small><small>${escapeHtml(c.phone)}</small></div></article>`).join("")}</div>
    </section></div>`;
}

function createAccountPage(): string {
  return `<section class="panel narrow"><div class="panel-heading"><div><h2>Open a bank account</h2><p>Choose a registered customer and opening balance.</p></div></div>
    ${bank.getCustomers().length ? `<form id="account-form" class="form">
      <label>Customer<select name="customerId" required>${customerOptions()}</select></label>
      <label>Opening balance (₹)<input name="balance" type="number" min="0" step="0.01" value="1000" required /></label>
      <button class="primary" type="submit">Create account</button></form>` : `<p class="empty padded">Register a customer before opening an account.</p>`}
  </section>`;
}

function transactionsPage(): string {
  return `<div class="two-column">
    <section class="panel"><div class="panel-heading"><div><h2>New transaction</h2><p>Deposit, withdraw or transfer funds.</p></div></div>
      <form id="transaction-form" class="form">
        <label>Transaction type<select name="kind" id="transaction-kind">
          <option value="deposit">Deposit</option><option value="withdrawal">Withdrawal</option><option value="transfer">Transfer</option>
        </select></label>
        <label id="source-label">Account<select name="accountNumber" id="source-account" required>${accountOptions()}</select></label>
        <label id="destination-label" class="hidden">Transfer to<select name="toAccount" id="destination-account">${accountOptions()}</select></label>
        <label>Amount (₹)<input name="amount" type="number" min="0.01" step="0.01" required placeholder="Enter amount" /></label>
        <button class="primary" type="submit">Submit transaction</button>
        <p class="hint">A transfer creates a debit record and a matching credit record.</p>
      </form>
    </section>
    <section class="panel"><div class="panel-heading"><div><h2>Account balances</h2><p>Current available balance.</p></div></div>${accountsTable(bank.getAccounts())}</section>
    </div>
    <section class="panel"><div class="panel-heading"><div><h2>Transaction ledger</h2><p>Newest transactions appear first.</p></div></div>
      <div class="table-wrap"><table><thead><tr><th>Date & time</th><th>Account</th><th>Type</th><th>Amount</th><th>Balance after</th><th>Description</th></tr></thead><tbody>${transactionRows(bank.getTransactions())}</tbody></table></div>
    </section>`;
}

function historyPage(): string {
  return `<section class="panel"><div class="panel-heading"><div><h2>Transaction history</h2><p>Filter the ledger by account.</p></div>
    <select id="history-account" class="compact-select"><option value="">All accounts</option>${accountOptions()}</select></div>
    <div class="table-wrap"><table><thead><tr><th>Date & time</th><th>Account</th><th>Type</th><th>Amount</th><th>Balance after</th><th>Description</th></tr></thead><tbody id="history-rows">${transactionRows(bank.getTransactions())}</tbody></table></div>
  </section>`;
}

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: "▦" },
  { id: "customers", label: "Customers", icon: "♙" },
  { id: "accounts", label: "Open account", icon: "▣" },
  { id: "transactions", label: "Transactions", icon: "⇄" },
  { id: "history", label: "History", icon: "◷" }
];

function render(): void {
  const content = activeTab === "dashboard" ? dashboard()
    : activeTab === "customers" ? customersPage()
    : activeTab === "accounts" ? createAccountPage()
    : activeTab === "transactions" ? transactionsPage()
    : historyPage();

  app!.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand"><div class="brand-mark">CB</div><div><strong>CampusBank</strong><small>Training simulator</small></div></div>
        <div class="nav-label">WORKSPACE</div>
        <nav>${navItems.map(item => `<button class="nav-item ${activeTab === item.id ? "active" : ""}" data-tab="${item.id}"><span class="nav-icon">${item.icon}</span>${item.label}</button>`).join("")}</nav>
        <div class="sidebar-bottom"><span class="demo-dot"></span><div><strong>Demo environment</strong><small>Sample data only</small></div></div>
      </aside>
      <main class="main-content">
        <header class="topbar"><div><p class="eyebrow">BANKING OPERATIONS</p><h1>${navItems.find(item => item.id === activeTab)?.label}</h1></div><div class="profile"><div class="avatar small">ST</div><div><strong>Student Trainer</strong><small>TypeScript project</small></div></div></header>
        ${notice ? `<div class="notice ${notice.kind}" role="status">${escapeHtml(notice.text)}<button id="dismiss-notice" aria-label="Dismiss message">×</button></div>` : ""}
        <div class="page-content">${content}</div>
        <footer>CampusBank · Educational project · Not for real banking transactions</footer>
      </main>
    </div>`;

  bindEvents();
}

function showNotice(text: string, kind: "success" | "error" = "success"): void {
  notice = { text, kind };
}

function bindEvents(): void {
  document.querySelectorAll<HTMLButtonElement>("[data-tab]").forEach(button => {
    button.addEventListener("click", () => {
      activeTab = button.dataset.tab ?? "dashboard";
      notice = null;
      render();
    });
  });

  document.querySelector<HTMLButtonElement>("#dismiss-notice")?.addEventListener("click", () => {
    notice = null;
    render();
  });

  document.querySelector<HTMLInputElement>("#account-search")?.addEventListener("input", event => {
    searchTerm = (event.currentTarget as HTMLInputElement).value;
    const wrapper = document.querySelector(".panel .table-wrap");
    if (wrapper) wrapper.innerHTML = accountsTable(bank.getAccounts());
  });

  document.querySelector<HTMLFormElement>("#customer-form")?.addEventListener("submit", event => {
    event.preventDefault();
    const form = new FormData(event.currentTarget as HTMLFormElement);
    const result = bank.createCustomer(
      String(form.get("name") ?? ""), String(form.get("email") ?? ""), String(form.get("phone") ?? "")
    );
    showNotice(result.success ? result.message : result.error, result.success ? "success" : "error");
    render();
  });

  document.querySelector<HTMLFormElement>("#account-form")?.addEventListener("submit", event => {
    event.preventDefault();
    const form = new FormData(event.currentTarget as HTMLFormElement);
    const result = bank.createAccount(String(form.get("customerId") ?? ""), Number(form.get("balance")));
    showNotice(result.success ? result.message : result.error, result.success ? "success" : "error");
    render();
  });

  const kindSelect = document.querySelector<HTMLSelectElement>("#transaction-kind");
  const destinationLabel = document.querySelector<HTMLLabelElement>("#destination-label");
  const destinationSelect = document.querySelector<HTMLSelectElement>("#destination-account");
  kindSelect?.addEventListener("change", () => {
    const isTransfer = kindSelect.value === "transfer";
    destinationLabel?.classList.toggle("hidden", !isTransfer);
    if (destinationSelect) destinationSelect.required = isTransfer;
  });

  document.querySelector<HTMLFormElement>("#transaction-form")?.addEventListener("submit", event => {
    event.preventDefault();
    const form = new FormData(event.currentTarget as HTMLFormElement);
    const kind = String(form.get("kind"));
    const amount = Number(form.get("amount"));
    let result;
    if (kind === "transfer") {
      result = bank.transact({
        kind: "transfer",
        fromAccount: String(form.get("accountNumber") ?? ""),
        toAccount: String(form.get("toAccount") ?? ""),
        amount
      });
    } else if (kind === "deposit") {
      result = bank.transact({ kind: "deposit", accountNumber: String(form.get("accountNumber") ?? ""), amount });
    } else {
      result = bank.transact({ kind: "withdrawal", accountNumber: String(form.get("accountNumber") ?? ""), amount });
    }
    showNotice(result.success ? result.message : result.error, result.success ? "success" : "error");
    render();
  });

  document.querySelector<HTMLSelectElement>("#history-account")?.addEventListener("change", event => {
    const accountNumber = (event.currentTarget as HTMLSelectElement).value;
    const rows = document.querySelector<HTMLTableSectionElement>("#history-rows");
    if (rows) rows.innerHTML = transactionRows(bank.getTransactions(accountNumber || undefined));
  });
}

render();
