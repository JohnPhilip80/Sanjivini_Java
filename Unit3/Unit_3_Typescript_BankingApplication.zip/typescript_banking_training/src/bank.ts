import type {
  BankAccount, BankState, Customer, OperationResult, Transaction,
  TransactionRequest
} from "./types";
import type { StateRepository } from "./storage";

const now = (): string => new Date().toISOString();
const makeId = (prefix: string): string =>
  `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;

export class Bank {
  private state: BankState;

  constructor(private readonly repository: StateRepository) {
    this.state = repository.load() ?? this.createDemoState();
    this.persist();
  }

  private createDemoState(): BankState {
    const customer1: Customer = {
      id: "CUS-1001", name: "Ananya Kumar", email: "ananya@example.com",
      phone: "9876543210", createdAt: now()
    };
    const customer2: Customer = {
      id: "CUS-1002", name: "Arjun Raj", email: "arjun@example.com",
      phone: "9876501234", createdAt: now()
    };
    const account1: BankAccount = {
      accountNumber: "10000001", customerId: customer1.id,
      balance: 12500, status: "active", createdAt: now()
    };
    const account2: BankAccount = {
      accountNumber: "10000002", customerId: customer2.id,
      balance: 8200, status: "active", createdAt: now()
    };
    return { customers: [customer1, customer2], accounts: [account1, account2], transactions: [] };
  }

  private persist(): void {
    this.repository.save(this.state);
  }

  getCustomers(): Customer[] {
    return this.state.customers.map(customer => ({ ...customer }));
  }

  getAccounts(): BankAccount[] {
    return this.state.accounts.map(account => ({ ...account }));
  }

  getTransactions(accountNumber?: string): Transaction[] {
    const items = accountNumber
      ? this.state.transactions.filter(tx => tx.accountNumber === accountNumber)
      : this.state.transactions;
    return items.map(tx => ({ ...tx })).sort((a, b) =>
      b.timestamp.localeCompare(a.timestamp));
  }

  getAccount(accountNumber: string): BankAccount | undefined {
    const account = this.state.accounts.find(item => item.accountNumber === accountNumber);
    return account ? { ...account } : undefined;
  }

  getCustomer(customerId: string): Customer | undefined {
    const customer = this.state.customers.find(item => item.id === customerId);
    return customer ? { ...customer } : undefined;
  }

  createCustomer(name: string, email: string, phone: string): OperationResult<Customer> {
    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();
    const cleanPhone = phone.trim();

    if (cleanName.length < 2) return { success: false, error: "Enter a customer name with at least 2 characters." };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      return { success: false, error: "Enter a valid email address." };
    }
    if (!/^[0-9+\-\s]{8,15}$/.test(cleanPhone)) {
      return { success: false, error: "Enter a valid phone number (8–15 characters)." };
    }
    if (this.state.customers.some(c => c.email === cleanEmail)) {
      return { success: false, error: "A customer with this email already exists." };
    }

    const customer: Customer = {
      id: `CUS-${Date.now().toString().slice(-8)}`,
      name: cleanName, email: cleanEmail, phone: cleanPhone, createdAt: now()
    };
    this.state.customers.push(customer);
    this.persist();
    return { success: true, data: { ...customer }, message: "Customer registered successfully." };
  }

  createAccount(customerId: string, openingBalance: number): OperationResult<BankAccount> {
    if (!this.state.customers.some(c => c.id === customerId)) {
      return { success: false, error: "Select an existing customer." };
    }
    if (!Number.isFinite(openingBalance) || openingBalance < 0) {
      return { success: false, error: "Opening balance must be zero or more." };
    }

    const account: BankAccount = {
      accountNumber: String(10000000 + Math.floor(Math.random() * 89999999)),
      customerId, balance: this.roundMoney(openingBalance), status: "active", createdAt: now()
    };
    while (this.state.accounts.some(a => a.accountNumber === account.accountNumber)) {
      account.accountNumber = String(10000000 + Math.floor(Math.random() * 89999999));
    }
    this.state.accounts.push(account);
    this.persist();
    return { success: true, data: { ...account }, message: `Account ${account.accountNumber} created successfully.` };
  }

  transact(request: TransactionRequest): OperationResult<Transaction[]> {
    // Advanced union type: TypeScript narrows request using request.kind.
    if (request.kind === "transfer") {
      return this.transfer(request.fromAccount, request.toAccount, request.amount);
    }
    if (request.kind === "deposit") {
      return this.deposit(request.accountNumber, request.amount);
    }
    return this.withdraw(request.accountNumber, request.amount);
  }

  private validateAmount(amount: number): string | null {
    if (!Number.isFinite(amount) || amount <= 0) return "Amount must be greater than zero.";
    if (Math.round(amount * 100) !== amount * 100) return "Use no more than 2 decimal places.";
    return null;
  }

  private findActiveAccount(accountNumber: string): BankAccount | undefined {
    return this.state.accounts.find(a => a.accountNumber === accountNumber && a.status === "active");
  }

  private roundMoney(amount: number): number {
    return Math.round((amount + Number.EPSILON) * 100) / 100;
  }

  private record(
    account: BankAccount, type: Transaction["type"], amount: number,
    description: string, relatedAccount?: string
  ): Transaction {
    const tx: Transaction = {
      id: makeId("TX"), accountNumber: account.accountNumber, type, amount,
      balanceAfter: account.balance, description, timestamp: now(),
      status: "success", ...(relatedAccount ? { relatedAccount } : {})
    };
    this.state.transactions.push(tx);
    return tx;
  }

  private deposit(accountNumber: string, amount: number): OperationResult<Transaction[]> {
    const error = this.validateAmount(amount);
    if (error) return { success: false, error };
    const account = this.findActiveAccount(accountNumber);
    if (!account) return { success: false, error: "Active account not found." };

    account.balance = this.roundMoney(account.balance + amount);
    const tx = this.record(account, "deposit", amount, "Cash deposit");
    this.persist();
    return { success: true, data: [tx], message: "Deposit completed successfully." };
  }

  private withdraw(accountNumber: string, amount: number): OperationResult<Transaction[]> {
    const error = this.validateAmount(amount);
    if (error) return { success: false, error };
    const account = this.findActiveAccount(accountNumber);
    if (!account) return { success: false, error: "Active account not found." };
    if (account.balance < amount) return { success: false, error: "Insufficient balance." };

    account.balance = this.roundMoney(account.balance - amount);
    const tx = this.record(account, "withdrawal", amount, "Cash withdrawal");
    this.persist();
    return { success: true, data: [tx], message: "Withdrawal completed successfully." };
  }

  private transfer(fromNumber: string, toNumber: string, amount: number): OperationResult<Transaction[]> {
    const error = this.validateAmount(amount);
    if (error) return { success: false, error };
    if (fromNumber === toNumber) return { success: false, error: "Source and destination accounts must be different." };

    const source = this.findActiveAccount(fromNumber);
    const destination = this.findActiveAccount(toNumber);
    if (!source) return { success: false, error: "Active source account not found." };
    if (!destination) return { success: false, error: "Active destination account not found." };
    if (source.balance < amount) return { success: false, error: "Insufficient balance for transfer." };

    // Both balances are updated before saving, so the demo transfer is atomic in this in-memory model.
    source.balance = this.roundMoney(source.balance - amount);
    destination.balance = this.roundMoney(destination.balance + amount);
    const out = this.record(source, "transfer-out", amount, `Transfer to ${toNumber}`, toNumber);
    const incoming = this.record(destination, "transfer-in", amount, `Transfer from ${fromNumber}`, fromNumber);
    this.persist();
    return { success: true, data: [out, incoming], message: "Transfer completed successfully." };
  }

  resetDemoData(): void {
    this.state = this.createDemoState();
    this.persist();
  }
}
