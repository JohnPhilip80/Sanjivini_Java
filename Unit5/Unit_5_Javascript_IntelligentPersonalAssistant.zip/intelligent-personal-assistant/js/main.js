import { TaskManager } from "./task-manager.js";
import { NoteManager } from "./note-manager.js";
import { ExpenseManager } from "./expense-manager.js";
import { Assistant } from "./assistant.js";
import { todayISO, formatCurrency, showToast } from "./utils.js";

const tasks = new TaskManager();
const notes = new NoteManager();
const expenses = new ExpenseManager();
const assistant = new Assistant();

const $ = (selector) => document.querySelector(selector);
const taskForm = $("#taskForm");
const noteForm = $("#noteForm");
const expenseForm = $("#expenseForm");
const taskList = $("#taskList");
const noteList = $("#noteList");
const expenseList = $("#expenseList");
const taskFilter = $("#taskFilter");

const refresh = () => {
  const stats = tasks.stats;
  $("#totalTasks").textContent = stats.total;
  $("#completedTasks").textContent = stats.completed;
  $("#pendingTasks").textContent = stats.pending;
  $("#totalExpenses").textContent = formatCurrency(expenses.total);
  const taskCount = tasks.render(taskList, taskFilter.value);
  $("#taskCount").textContent = `${taskCount} task${taskCount === 1 ? "" : "s"}`;
  $("#emptyTasks").hidden = taskCount > 0;
  $("#emptyNotes").hidden = notes.render(noteList) > 0;
  $("#emptyExpenses").hidden = expenses.render(expenseList) > 0;
  assistant.render($("#assistantSummary"), { tasks: tasks.all, expenses: expenses.all });
  const overdue = tasks.overdue.length;
  $("#dailyMessage").textContent = overdue
    ? `You have ${overdue} overdue ${overdue === 1 ? "activity" : "activities"}. Let's decide what to tackle first.`
    : stats.pending
      ? `You have ${stats.pending} pending ${stats.pending === 1 ? "activity" : "activities"}. One step at a time.`
      : "No pending tasks recorded. Add an activity to plan your day.";
};

const setupHeader = () => {
  const now = new Date();
  $("#todayLabel").textContent = new Intl.DateTimeFormat(undefined, {
    weekday: "long", day: "numeric", month: "long", year: "numeric"
  }).format(now);
  const hour = now.getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  $("#greeting").textContent = `${greeting}!`;
  $("#taskDueDate").value = todayISO();
};

taskForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    tasks.add({
      title: $("#taskTitle").value,
      dueDate: $("#taskDueDate").value,
      priority: $("#taskPriority").value
    });
    taskForm.reset();
    $("#taskDueDate").value = todayISO();
    refresh();
    showToast("Task added.");
  } catch (error) { showToast(error.message); }
});

taskFilter.addEventListener("change", refresh);

taskList.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const item = button.closest("[data-id]");
  const { id } = item.dataset;
  try {
    switch (button.dataset.action) {
      case "toggle": tasks.toggle(id); break;
      case "delete": tasks.remove(id); showToast("Task deleted."); break;
      case "edit": {
        const task = tasks.all.find((entry) => entry.id === id);
        const updated = window.prompt("Edit task title:", task?.title ?? "");
        if (updated === null) return;
        tasks.edit(id, updated);
        showToast("Task updated.");
        break;
      }
    }
    refresh();
  } catch (error) { showToast(error.message); }
});

noteForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    notes.add({ title: $("#noteTitle").value, body: $("#noteBody").value });
    noteForm.reset();
    refresh();
    showToast("Note saved.");
  } catch (error) { showToast(error.message); }
});

noteList.addEventListener("click", (event) => {
  const button = event.target.closest('button[data-action="delete"]');
  if (!button) return;
  notes.remove(button.closest("[data-id]").dataset.id);
  refresh();
  showToast("Note deleted.");
});

expenseForm.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    expenses.add({
      title: $("#expenseTitle").value,
      amount: $("#expenseAmount").value,
      category: $("#expenseCategory").value
    });
    expenseForm.reset();
    refresh();
    showToast("Expense recorded.");
  } catch (error) { showToast(error.message); }
});

expenseList.addEventListener("click", (event) => {
  const button = event.target.closest('button[data-action="delete"]');
  if (!button) return;
  expenses.remove(button.closest("[data-id]").dataset.id);
  refresh();
  showToast("Expense deleted.");
});

$("#refreshAssistant").addEventListener("click", () => {
  assistant.render($("#assistantSummary"), { tasks: tasks.all, expenses: expenses.all });
  showToast("Suggestions refreshed.");
});

// Small asynchronous example: Promise + async/await + Fetch API.
// It uses a public placeholder endpoint and gracefully falls back when offline.
const loadOptionalTip = async () => {
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/todos/1");
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const { title } = await response.json(); // destructuring
    console.info(`Optional learning tip loaded: ${title}`);
  } catch (error) {
    console.info("Optional network demo skipped (offline or blocked).", error.message);
  }
};

setupHeader();
refresh();
loadOptionalTip();
