import { loadData, saveData } from "./storage.js";
import { makeId, todayISO, formatDate, escapeHTML } from "./utils.js";

export class TaskManager {
  #tasks = loadData("tasks", []);

  get all() { return [...this.#tasks]; }

  add({ title, dueDate = todayISO(), priority = "medium" } = {}) {
    const cleanTitle = String(title ?? "").trim();
    if (!cleanTitle) throw new Error("Please enter a task description.");
    const task = {
      id: makeId(), title: cleanTitle, dueDate, priority,
      completed: false, createdAt: new Date().toISOString()
    };
    this.#tasks = [task, ...this.#tasks];
    this.#persist();
    return task;
  }

  toggle(id) {
    this.#tasks = this.#tasks.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task
    );
    this.#persist();
  }

  edit(id, title) {
    const cleanTitle = String(title ?? "").trim();
    if (!cleanTitle) throw new Error("Task title cannot be empty.");
    this.#tasks = this.#tasks.map((task) =>
      task.id === id ? { ...task, title: cleanTitle } : task
    );
    this.#persist();
  }

  remove(id) {
    this.#tasks = this.#tasks.filter(({ id: taskId }) => taskId !== id);
    this.#persist();
  }

  get stats() {
    const total = this.#tasks.length;
    const completed = this.#tasks.filter(({ completed }) => completed).length;
    return { total, completed, pending: total - completed };
  }

  get overdue() {
    const today = todayISO();
    return this.#tasks.filter(({ completed, dueDate }) => !completed && dueDate < today);
  }

  render(listElement, filter = "all") {
    const tasks = this.#tasks.filter(({ completed }) =>
      filter === "all" || (filter === "completed" ? completed : !completed)
    );
    listElement.innerHTML = tasks.map((task) => `
      <li class="item ${task.completed ? "completed" : ""}" data-id="${escapeHTML(task.id)}">
        <button class="check-button" data-action="toggle" aria-label="${task.completed ? "Mark pending" : "Complete task"}">${task.completed ? "✓" : "○"}</button>
        <div class="item-content">
          <div class="item-title">${escapeHTML(task.title)}<span class="pill priority-${escapeHTML(task.priority)}">${escapeHTML(task.priority)}</span></div>
          <div class="item-meta">Due ${formatDate(task.dueDate)}${task.dueDate < todayISO() && !task.completed ? " · Overdue" : ""}</div>
        </div>
        <div class="item-actions">
          <button class="icon-button" data-action="edit" aria-label="Edit task">Edit</button>
          <button class="icon-button" data-action="delete" aria-label="Delete task">Delete</button>
        </div>
      </li>`).join("");
    return tasks.length;
  }

  #persist() { saveData("tasks", this.#tasks); }
}
