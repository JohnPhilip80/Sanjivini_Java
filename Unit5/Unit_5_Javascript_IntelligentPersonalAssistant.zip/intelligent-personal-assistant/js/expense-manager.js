import { loadData, saveData } from "./storage.js";
import { makeId, formatDate, formatCurrency, todayISO, escapeHTML, sumNumbers } from "./utils.js";

export class ExpenseManager {
  #expenses = loadData("expenses", []);
  get all() { return [...this.#expenses]; }

  add({ title, amount, category = "Other" } = {}) {
    const cleanTitle = String(title ?? "").trim();
    const numericAmount = Number(amount);
    if (!cleanTitle) throw new Error("Please enter an expense description.");
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) throw new Error("Amount must be greater than zero.");
    const expense = {
      id: makeId(), title: cleanTitle, amount: numericAmount, category,
      date: todayISO(), createdAt: new Date().toISOString()
    };
    this.#expenses = [expense, ...this.#expenses];
    saveData("expenses", this.#expenses);
    return expense;
  }

  remove(id) {
    this.#expenses = this.#expenses.filter(({ id: expenseId }) => expenseId !== id);
    saveData("expenses", this.#expenses);
  }

  get total() {
    return sumNumbers(...this.#expenses.map(({ amount }) => amount));
  }

  render(listElement) {
    listElement.innerHTML = this.#expenses.map((expense) => `
      <li class="item" data-id="${escapeHTML(expense.id)}">
        <div class="item-content">
          <div class="item-title">${escapeHTML(expense.title)}</div>
          <div class="item-meta">${escapeHTML(expense.category)} · ${formatDate(expense.date)}</div>
        </div>
        <div class="item-actions">
          <strong>${formatCurrency(expense.amount)}</strong>
          <button class="icon-button" data-action="delete" aria-label="Delete expense">×</button>
        </div>
      </li>`).join("");
    return this.#expenses.length;
  }
}
