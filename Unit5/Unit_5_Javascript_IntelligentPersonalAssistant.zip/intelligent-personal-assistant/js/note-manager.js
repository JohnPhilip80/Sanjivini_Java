import { loadData, saveData } from "./storage.js";
import { makeId, formatDate, escapeHTML } from "./utils.js";

export class NoteManager {
  #notes = loadData("notes", []);
  get all() { return [...this.#notes]; }

  add({ title, body } = {}) {
    const cleanTitle = String(title ?? "").trim();
    const cleanBody = String(body ?? "").trim();
    if (!cleanTitle || !cleanBody) throw new Error("Enter both a note title and note text.");
    const note = { id: makeId(), title: cleanTitle, body: cleanBody, createdAt: new Date().toISOString() };
    this.#notes = [note, ...this.#notes];
    saveData("notes", this.#notes);
    return note;
  }

  remove(id) {
    this.#notes = this.#notes.filter(({ id: noteId }) => noteId !== id);
    saveData("notes", this.#notes);
  }

  render(listElement) {
    listElement.innerHTML = this.#notes.map((note) => `
      <li class="item" data-id="${escapeHTML(note.id)}">
        <div class="item-content">
          <div class="item-title">${escapeHTML(note.title)}</div>
          <div class="item-meta">${escapeHTML(note.body).replace(/\n/g, "<br>")}<br>Saved ${formatDate(note.createdAt.slice(0, 10))}</div>
        </div>
        <div class="item-actions"><button class="icon-button" data-action="delete" aria-label="Delete note">Delete</button></div>
      </li>`).join("");
    return this.#notes.length;
  }
}
