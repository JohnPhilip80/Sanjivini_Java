import { todayISO, formatCurrency } from "./utils.js";

export class Assistant {
  // This is rule-based assistance, not a generative AI model.
  summarize({ tasks = [], expenses = [] } = {}) {
    const today = todayISO();
    const pending = tasks.filter((task) => !task.completed);
    const overdue = pending.filter((task) => task.dueDate < today);
    const highPriority = pending.filter((task) => task.priority === "high");
    const todayTasks = tasks.filter((task) => task.dueDate === today);
    const totalSpent = expenses.reduce((sum, expense) => sum + Number(expense.amount), 0);

    const suggestions = [];
    if (overdue.length) {
      suggestions.push({
        title: "Review overdue activities",
        body: `You have ${overdue.length} overdue task${overdue.length === 1 ? "" : "s"}. Consider rescheduling or completing one now.`
      });
    }
    if (highPriority.length) {
      suggestions.push({
        title: "Focus on high priority",
        body: `${highPriority.length} high-priority task${highPriority.length === 1 ? "" : "s"} pending. Try starting with the most urgent one.`
      });
    }
    if (todayTasks.length) {
      suggestions.push({
        title: "Today's plan",
        body: `${todayTasks.length} task${todayTasks.length === 1 ? "" : "s"} due today; ${todayTasks.filter((task) => task.completed).length} completed so far.`
      });
    }
    if (!pending.length) {
      suggestions.push({ title: "You're all caught up", body: "No pending tasks recorded. Add a new activity when you are ready." });
    }
    suggestions.push({
      title: "Spending snapshot",
      body: `Total expenses recorded: ${formatCurrency(totalSpent)}. Review categories regularly to understand your spending.`
    });
    return suggestions;
  }

  render(element, data) {
    const suggestions = this.summarize(data);
    element.innerHTML = suggestions.map(({ title, body }) => `
      <div class="suggestion"><strong>${title}</strong>${body}</div>`).join("");
  }
}
