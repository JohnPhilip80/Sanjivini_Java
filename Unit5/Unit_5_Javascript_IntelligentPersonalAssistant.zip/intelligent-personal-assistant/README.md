# DayMate — Intelligent Personal Assistant

A browser-based training project for 2nd-year undergraduate Computer Science students. It demonstrates modern JavaScript (ECMAScript 6+) with ES modules, classes, private fields, arrow functions, destructuring, spread/rest syntax, template literals, Promises, `async`/`await`, and the Fetch API.

## Features
- Daily dashboard and task statistics
- Create, edit, complete, filter, and delete tasks
- Save and delete notes
- Record and delete expenses; calculate total spending
- Rule-based assistant suggestions for overdue and high-priority tasks
- Local Storage persistence
- Responsive layout and basic input validation
- HTML escaping before inserting user text into the page

## Run the project
Because the app uses JavaScript ES modules, open it through a local web server rather than `file://`.

### Option A: Visual Studio Code
1. Extract the ZIP file.
2. Open the `intelligent-personal-assistant` folder in VS Code.
3. Install the **Live Server** extension if it is not already installed.
4. Right-click `index.html` and choose **Open with Live Server**.

### Option B: Python installed
Open a terminal in this folder and run:
```bash
python -m http.server 8000
```
Then open `http://localhost:8000` in your browser.

No npm packages or build tools are required. The optional Fetch API demonstration calls JSONPlaceholder; the main app works offline without that request. Records are stored in the current browser's Local Storage. Clearing browser site data removes those records.

## Project structure
```text
intelligent-personal-assistant/
├── index.html
├── styles.css
├── README.md
└── js/
    ├── main.js
    ├── storage.js
    ├── utils.js
    ├── task-manager.js
    ├── note-manager.js
    ├── expense-manager.js
    └── assistant.js
```

## Suggested 9-hour training plan

| Time | Topics | Hands-on milestone |
|---|---|---|
| Hour 1 | Introduction to ECMAScript; `let`, `const`, variables and scope | Inspect project files; create sample activity data |
| Hour 2 | Arrow functions; template literals | Build greeting, date formatting and dynamic message strings |
| Hour 3 | Destructuring; default, rest and spread operators | Extract form values, set defaults, update objects immutably |
| Hour 4 | Enhanced object literals; arrays and methods | Model tasks, notes and expense records |
| Hour 5 | Classes; constructors, methods and private fields | Implement `TaskManager` and discuss encapsulation |
| Hour 6 | ES modules; `import` and `export` | Separate task, note, expense, utility and storage code |
| Hour 7 | DOM events, forms, rendering and Local Storage | Complete CRUD workflows and persist records |
| Hour 8 | Promises, `async`/`await`, Fetch API and error handling | Inspect the optional network request and offline fallback |
| Hour 9 | Integration, debugging, testing and extension activity | Test the app, explain code, and add one feature |

The timing is a suggested plan; some students may need additional support for DOM events and asynchronous programming.

## ECMAScript concepts in the source

- **Variables and scoping:** `const`, `let`, block scope, module scope.
- **Arrow functions:** callbacks, array transformations and event handlers.
- **Template literals:** dynamic HTML strings and messages.
- **Destructuring:** task and note objects; Fetch response payload.
- **Default parameters:** optional arguments in manager methods.
- **Rest/spread:** object updates with `{ ...task, completed: ... }`; encourage students to add a rest-parameter helper as an exercise.
- **Enhanced object literals:** object shorthand and method syntax can be added in the assistant or data-model exercises.
- **Modules:** each JavaScript file exports a focused class or helper.
- **Classes:** task, note, expense and assistant classes.
- **Promises and async programming:** `fetch`, `response.json()`, `async`/`await`, `try`/`catch`.

## Instructor notes
1. Start with the finished app for a 5-minute demonstration.
2. Ask students to identify data, UI, and persistence responsibilities.
3. Build in small checkpoints rather than pasting all files at once.
4. Use browser DevTools: Console, Elements, and Application → Local Storage.
5. Have students test empty input, invalid expense amounts, deletion, refresh persistence, and overdue tasks.
6. Explain that the “intelligence” is rule-based. Connecting a real AI service would require a secure backend and API-key handling; never put private API keys in frontend JavaScript.

## Student extension challenges
- Add a search box for tasks and notes.
- Add a weekly expense breakdown by category.
- Add export/import as JSON or CSV.
- Add a habit tracker or study timer.
- Add browser notifications for reminders (with permission handling).
- Add unit tests for the manager classes.
- Add a backend and database as a separate advanced assignment.

## Limitations
- Data belongs to one browser profile and is not synchronized across devices.
- Reminders are displayed as records; this starter version does not send notifications at a scheduled time.
- The optional Fetch API call requires internet access.
- The app is an educational starter project, not a secure multi-user production system.
